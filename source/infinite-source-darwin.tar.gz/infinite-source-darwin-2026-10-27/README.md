Source correspondante au binaire « darwin » d'Infinite Media Player
================================================================

Ce que contient cette archive
-----------------------------

  Licence de ce qui est livré :
    LGPL 2.1 (mpv) et LGPL v3 (FFmpeg) — vérifié dans la recette : mpv est compilé avec -Dgpl=false, et FFmpeg sans --enable-gpl.

  mpv/                       le source de mpv, à la version exacte compilée
  ffmpeg/                    le source de FFmpeg, à la version exacte compilée
  media-kit-build/           la recette de compilation complète, avec son
                             fichier de verrouillage et ses correctifs
  LICENSES/                  les textes de licence (LGPL 2.1, LGPL v3, GPL v3)
  LIGNE-DE-COMPILATION.txt   les commandes de compilation, telles qu'elles
                             ont servi à produire le binaire livré
  SHA256SUMS                 les sommes de contrôle des deux sources

Les versions, sans exception
---------------------------

  mpv     0.36.0
  FFmpeg  6.0

Ces versions ne sont pas choisies : elles sont lues dans le fichier de
verrouillage du dépôt de compilation ci-dessous. C'est ce qui fait que le
source livré ici correspond exactement au binaire distribué.

  Dépôt de compilation : https://github.com/media-kit/libmpv-darwin-build
  Release épinglée     : v0.6.0
  Fichier verrouillé   : downloads.lock

La commande exacte pour reproduire le binaire
----------------------------------------------

    git clone --branch v0.6.0 --depth 1 https://github.com/media-kit/libmpv-darwin-build.git
    cd libmpv-darwin-build
    # macOS : xcframework universel (slice arm64 et slice amd64)
    make VERSION=v0.6.0 build/output/libmpv-xcframeworks_v0.6.0_macos-universal-video-default.tar.gz
    # iOS : xcframework universel (slice arm64 et slice simulateur)
    make VERSION=v0.6.0 build/output/libmpv-xcframeworks_v0.6.0_ios-universal-video-default.tar.gz

Les détails de configuration — les options de meson, les options de
configure de FFmpeg, les correctifs appliqués — sont dans
LIGNE-DE-COMPILATION.txt et dans media-kit-build/.

Ce que la LGPL demande, et ce que cette archive y répond
---------------------------------------------------------

  — Le source est fourni, et il correspond au binaire livré.
  — La ligne de compilation exacte est fournie.
  — Les textes de licence sont fournis (LGPL 2.1, LGPL v3, GPL v3).
  — La bibliothèque est partagée et rechargeable : vous pouvez la
    remplacer par une version modifiée de votre côté.

Si vous remplacez la bibliothèque, la licence reste la LGPL : c'est à
vous de la respecter pour votre version modifiée.

Les autres composants embarqués — libass (ISC), dav1d (BSD 2 clauses),
media_kit (MIT), Roboto (Apache 2) — n'imposent pas la publication du
source. Leurs textes de licence complets sont livrés dans
l'application elle-même, écran « Licences ».

Si vous préférez recevoir le source sur simple demande écrite, c'est
possible : l'offre écrite, publiée avec l'application, promet de
fournir le source pendant trois ans. Elle est disponible en français
et en anglais.

Généré le 2026-10-27 par apps/flutter/tool/prepare-source-offer.sh.
