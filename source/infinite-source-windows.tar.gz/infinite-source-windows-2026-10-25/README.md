Source correspondante au binaire « windows » d'Infinite Media Player
================================================================

Ce que contient cette archive
-----------------------------

  mpv/                       le source de mpv, à la version exacte compilée
  ffmpeg/                    le source de FFmpeg, à la version exacte compilée
  media-kit-build/           la recette de compilation complète, avec son
                             fichier de verrouillage et ses correctifs
  LICENSES/                  les textes de licence (LGPL 2.1, LGPL v3, GPL v3)
  LIGNE-DE-COMPILATION.txt   les commandes de compilation, telles qu'elles
                             sont écrites dans la recette
  SHA256SUMS                 les sommes de contrôle des deux sources

Les versions, sans exception
---------------------------

  mpv     commit 0f7858451817
  FFmpeg  commit 8d940a07d190

Ces versions ne sont pas choisies : elles sont lues dans le fichier de
verrouillage du dépôt de compilation ci-dessous. C'est ce qui fait que le
source livré ici correspond exactement au binaire distribué.

  Dépôt de compilation : https://github.com/media-kit/libmpv-win32-video-cmake
  Release épinglée     : 20241021
  Fichier verrouillé   : packages/ffmpeg.cmake
  Commit de mpv        : 0f7858451817c5fd5ebdb74a807a7c997662c390
  Commit de FFmpeg     : 8d940a07d19023a98689f353e4425a14688547e9

La commande exacte pour reproduire le binaire
----------------------------------------------

    git clone --branch 20241021 --depth 1 https://github.com/media-kit/libmpv-win32-video-cmake.git
    cd libmpv-win32-video-cmake
    cmake -DTARGET_ARCH=x86_64-w64-mingw32 -DCOMPILER_TOOLCHAIN=clang \
      -DCMAKE_INSTALL_PREFIX=$PWD/clang_root \
      -DMINGW_INSTALL_PREFIX=$PWD/build_x86_64/x86_64-w64-mingw32 \
      -DSINGLE_SOURCE_LOCATION=$PWD/src_packages -DRUSTUP_LOCATION=$PWD/clang_root/install_rustup \
      -DENABLE_CCACHE=ON -DCLANG_PACKAGES_LTO=ON -G Ninja --fresh -B build_x86_64 -S $PWD
    ninja -C build_x86_64 mpv
    ninja -C build_x86_64 mpv-packaging

Les détails de configuration — les options de meson, les options de
configure de FFmpeg, les correctifs appliqués — sont dans
LIGNE-DE-COMPILATION.txt et dans media-kit-build/.

Ce que la LGPL demande, et ce que cette archive y répond
---------------------------------------------------------

  — Le source est fourni, et il correspond au binaire livré.
  — La ligne de compilation exacte est fournie.
  — Les textes de licence sont fournis (LGPL 2.1, LGPL v3, GPL v3).
  — La bibliothèque est partagée et rechargeable : vous pouvez la
    remplacer par une version modifiée de votre côté.

Si vous remplacez la bibliothèque, la licence reste la LGPL : c'est à
vous de la respecter pour votre version modifiée.

Les autres composants embarqués — libass (ISC), dav1d (BSD 2 clauses),
media_kit (MIT) — n'imposent pas la publication du source. Leurs textes
de licence complets sont livrés dans l'application elle-même, écran
« Licences ».

Si vous préférez recevoir le source sur simple demande écrite, c'est
possible : l'offre écrite, publiée avec l'application, promet de
fournir le source pendant trois ans. Elle est disponible en français
et en anglais.

Généré le 2026-10-25 par apps/flutter/tool/prepare-source-offer.sh.
