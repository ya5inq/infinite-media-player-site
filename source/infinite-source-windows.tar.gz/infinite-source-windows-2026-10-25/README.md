Source correspondante au binaire « windows » d'Infinite Media Player
================================================================

Ce que contient cette archive
-----------------------------

  Licence de ce qui est livré :
    LGPL 2.1 (mpv) et LGPL v3 (FFmpeg) — vérifié dans le binaire livré lui-même : « libavcodec license: LGPL version 3 or later », et une configuration FFmpeg en « --disable-gpl --disable-nonfree --enable-version3 ».

  mpv/                       le source de mpv, à la version exacte compilée
  ffmpeg/                    le source de FFmpeg, à la version exacte compilée
  media-kit-build/           la recette de compilation complète, avec son
                             fichier de verrouillage et ses correctifs
  LICENSES/                  les textes de licence (LGPL 2.1, LGPL v3, GPL v3)
  LIGNE-DE-COMPILATION.txt   les commandes de compilation, telles qu'elles
                             ont servi à produire le binaire livré
  SHA256SUMS                 les sommes de contrôle des deux sources

Les versions, sans exception
---------------------------

  mpv     commit 652a1dd90711
  FFmpeg  6.0

Ces versions ne sont pas choisies : elles sont lues dans le binaire
livré lui-même — le nom de l'archive publiée pour mpv, et la version
inscrite dans la bibliothèque pour FFmpeg. C'est ce qui fait que le
source livré ici correspond exactement au binaire distribué.

  Dépôt de compilation : https://github.com/media-kit/libmpv-win32-video-build
  Release épinglée     : 2023-09-24
  Fichier verrouillé   : aucun — la version est lue dans le binaire livré
  Commit de mpv        : 652a1dd90711839acdccc08004056d25514ef2d8
  Commit de FFmpeg     : ea3d24bbe3c58b171e55fe2151fc7ffaca3ab3d2

La commande exacte pour reproduire le binaire
----------------------------------------------

    git clone --branch 2023-09-24 --depth 1 https://github.com/media-kit/libmpv-win32-video-build.git
    cd libmpv-win32-video-build
    # Le système de compilation est « mpv-winbuild-cmake » : CMake, Ninja, et
    # une toolchain MinGW. Le binaire publié a été compilé dans un répertoire
    # « build64 » ; la configuration effective est dans LIGNE-DE-COMPILATION.txt.
    cmake -DTARGET_ARCH=x86_64-w64-mingw32 -DCOMPILER_TOOLCHAIN=clang \
      -DCMAKE_INSTALL_PREFIX=$PWD/clang_root \
      -DMINGW_INSTALL_PREFIX=$PWD/build_x86_64/x86_64-w64-mingw32 \
      -DSINGLE_SOURCE_LOCATION=$PWD/src_packages -DRUSTUP_LOCATION=$PWD/clang_root/install_rustup \
      -DENABLE_CCACHE=ON -DCLANG_PACKAGES_LTO=ON -G Ninja --fresh -B build_x86_64 -S $PWD
    ninja -C build_x86_64 mpv
    ninja -C build_x86_64 mpv-packaging

Les détails de configuration — les options de meson, les options de
configure de FFmpeg, les correctifs appliqués — sont dans
LIGNE-DE-COMPILATION.txt et dans media-kit-build/.

Ce que la LGPL demande, et ce que cette archive y répond
---------------------------------------------------------

  — Le source est fourni, et il correspond au binaire livré.
  — La ligne de compilation exacte est fournie.
  — Les textes de licence sont fournis (LGPL 2.1, LGPL v3, GPL v3).
  — La bibliothèque est partagée et rechargeable : vous pouvez la
    remplacer par une version modifiée de votre côté.

Si vous remplacez la bibliothèque, la licence reste la LGPL : c'est à
vous de la respecter pour votre version modifiée.

Les autres composants embarqués — libass (ISC), dav1d (BSD 2 clauses),
media_kit (MIT) — n'imposent pas la publication du source. Leurs textes
de licence complets sont livrés dans l'application elle-même, écran
« Licences ».

Si vous préférez recevoir le source sur simple demande écrite, c'est
possible : l'offre écrite, publiée avec l'application, promet de
fournir le source pendant trois ans. Elle est disponible en français
et en anglais.

Généré le 2026-10-25 par apps/flutter/tool/prepare-source-offer.sh.
