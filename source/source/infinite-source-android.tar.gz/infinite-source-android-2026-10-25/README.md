Source correspondante au binaire « android » d'Infinite Media Player
================================================================

Ce que contient cette archive
-----------------------------

  mpv/                       le source de mpv, à la version exacte compilée
  ffmpeg/                    le source de FFmpeg, à la version exacte compilée
  media-kit-build/           la recette de compilation complète, avec son
                             fichier de verrouillage et ses correctifs
  LICENSES/                  les textes de licence (LGPL 2.1, LGPL v3, GPL v3)
  LIGNE-DE-COMPILATION.txt   les commandes de compilation, telles qu'elles
                             sont écrites dans la recette
  SHA256SUMS                 les sommes de contrôle des deux sources

Les versions, sans exception
---------------------------

  mpv     commit 78d43740f52d
  FFmpeg  6.0

Ces versions ne sont pas choisies : elles sont lues dans le fichier de
verrouillage du dépôt de compilation ci-dessous. C'est ce qui fait que le
source livré ici correspond exactement au binaire distribué.

  Dépôt de compilation : https://github.com/media-kit/libmpv-android-video-build
  Release épinglée     : v1.1.7
  Fichier verrouillé   : buildscripts/include/depinfo.sh
  Commit de mpv        : 78d43740f52db817d98bcf24fb30a76ab6fa13ff
  Commit de FFmpeg     : ea3d24bbe3c58b171e55fe2151fc7ffaca3ab3d2

La commande exacte pour reproduire le binaire
----------------------------------------------

    git clone --branch v1.1.7 --depth 1 https://github.com/media-kit/libmpv-android-video-build.git
    cd libmpv-android-video-build/buildscripts
    ./download.sh     # récupère mpv (commit 78d43740f52db817d98bcf24fb30a76ab6fa13ff) et FFmpeg (n6.0)
    ./patch.sh        # applique les correctifs media-kit
    ./build.sh        # compile libmpv pour les quatre ABI

Les détails de configuration — les options de meson, les options de
configure de FFmpeg, les correctifs appliqués — sont dans
LIGNE-DE-COMPILATION.txt et dans media-kit-build/.

Ce que la LGPL demande, et ce que cette archive y répond
---------------------------------------------------------

  — Le source est fourni, et il correspond au binaire livré.
  — La ligne de compilation exacte est fournie.
  — Les textes de licence sont fournis (LGPL 2.1, LGPL v3, GPL v3).
  — La bibliothèque est partagée et rechargeable : vous pouvez la
    remplacer par une version modifiée de votre côté.

Si vous remplacez la bibliothèque, la licence reste la LGPL : c'est à
vous de la respecter pour votre version modifiée.

Les autres composants embarqués — libass (ISC), dav1d (BSD 2 clauses),
media_kit (MIT) — n'imposent pas la publication du source. Leurs textes
de licence complets sont livrés dans l'application elle-même, écran
« Licences ».

Si vous préférez recevoir le source sur simple demande écrite, c'est
possible : l'offre écrite, publiée avec l'application, promet de
fournir le source pendant trois ans. Elle est disponible en français
et en anglais.

Généré le 2026-10-25 par apps/flutter/tool/prepare-source-offer.sh.
