Source correspondante au binaire « windows » d'Infinite Media Player
================================================================

Ce que contient cette archive
-----------------------------

  ATTENTION — CETTE RECETTE NE PRODUIT PAS UN BINAIRE LGPL.
  
  La ligne de compilation de FFmpeg (packages/ffmpeg.cmake) contient
  --enable-gpl, --enable-version3, --enable-nonfree, --enable-libx264 et
  --enable-libx265. FFmpeg y est compilé en statique et lié dans
  libmpv-2.dll : le binaire obtenu est sous GPL v3, et le « configure » de
  FFmpeg le déclare lui-même « nonfree and unredistributable ».
  
  Cette archive est exacte — elle correspond bien au binaire que
  media_kit_libs_windows_video 1.0.11 télécharge — mais elle documente un
  binaire qu'il ne faut pas redistribuer dans une application propriétaire.
  
  Pour un binaire LGPL, la recette à utiliser est
  media-kit/libmpv-win32-video-cmake (release 20241021) : FFmpeg y est compilé
  avec --disable-gpl --disable-nonfree --enable-version3, et mpv avec
  -Dgpl=false. Voir docs/source/lignes-de-compilation.md, §5.

  mpv/                       le source de mpv, à la version exacte compilée
  ffmpeg/                    le source de FFmpeg, à la version exacte compilée
  media-kit-build/           la recette de compilation complète, avec son
                             fichier de verrouillage et ses correctifs
  LICENSES/                  les textes de licence (LGPL 2.1, LGPL v3, GPL v3)
  LIGNE-DE-COMPILATION.txt   les commandes de compilation, telles qu'elles
                             sont écrites dans la recette
  SHA256SUMS                 les sommes de contrôle des deux sources

Les versions, sans exception
---------------------------

  mpv     commit 652a1dd90711
  FFmpeg  commit b61733f61ff2

Ces versions ne sont pas choisies : elles sont lues dans le fichier de
verrouillage du dépôt de compilation ci-dessous. C'est ce qui fait que le
source livré ici correspond exactement au binaire distribué.

  Dépôt de compilation : https://github.com/media-kit/libmpv-win32-video-build
  Release épinglée     : 2023-09-24
  Fichier verrouillé   : packages/ffmpeg.cmake
  Commit de mpv        : 652a1dd90711839acdccc08004056d25514ef2d8
  Commit de FFmpeg     : b61733f61ff2f61b1208fb661e278f704680d6a6

La commande exacte pour reproduire le binaire
----------------------------------------------

    git clone --branch 2023-09-24 --depth 1 https://github.com/media-kit/libmpv-win32-video-build.git
    cd libmpv-win32-video-build
    cmake -DTARGET_ARCH=x86_64-w64-mingw32 -DCOMPILER_TOOLCHAIN=clang \
      -DCMAKE_INSTALL_PREFIX=$PWD/clang_root \
      -DMINGW_INSTALL_PREFIX=$PWD/build_x86_64/x86_64-w64-mingw32 \
      -DSINGLE_SOURCE_LOCATION=$PWD/src_packages -DRUSTUP_LOCATION=$PWD/clang_root/install_rustup \
      -DENABLE_CCACHE=ON -DCLANG_PACKAGES_LTO=ON -G Ninja --fresh -B build_x86_64 -S $PWD
    ninja -C build_x86_64 mpv
    ninja -C build_x86_64 mpv-packaging

Les détails de configuration — les options de meson, les options de
configure de FFmpeg, les correctifs appliqués — sont dans
LIGNE-DE-COMPILATION.txt et dans media-kit-build/.

Ce que la LGPL demande, et ce que cette archive y répond
---------------------------------------------------------

  — Le source est fourni, et il correspond au binaire livré.
  — La ligne de compilation exacte est fournie.
  — Les textes de licence sont fournis (LGPL 2.1, LGPL v3, GPL v3).
  — La bibliothèque est partagée et rechargeable : vous pouvez la
    remplacer par une version modifiée de votre côté.

Si vous remplacez la bibliothèque, la licence reste la LGPL : c'est à
vous de la respecter pour votre version modifiée.

Les autres composants embarqués — libass (ISC), dav1d (BSD 2 clauses),
media_kit (MIT) — n'imposent pas la publication du source. Leurs textes
de licence complets sont livrés dans l'application elle-même, écran
« Licences ».

Si vous préférez recevoir le source sur simple demande écrite, c'est
possible : l'offre écrite, publiée avec l'application, promet de
fournir le source pendant trois ans. Elle est disponible en français
et en anglais.

Généré le 2026-10-25 par apps/flutter/tool/prepare-source-offer.sh.
